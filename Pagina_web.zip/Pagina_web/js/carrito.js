// 1. Creamos la variable del carrito como una lista vacía normal.
let carrito = [];

// Esperamos a que la página cargue por completo
window.onload = function () {
  //  PARTE 1: AÑADIR AL CARRITO
  const botonesAgregar = document.querySelectorAll(".boton-agregar-carrito");

  for (let i = 0; i < botonesAgregar.length; i++) {
    botonesAgregar[i].addEventListener("click", function (evento) {
      const tarjeta = evento.target.parentElement;
      const nombre = tarjeta.querySelector(".titulo-producto").textContent;
      const precioTexto = tarjeta.querySelector(".precio-normal").textContent;

      // Convertimos el texto "S/ 1,499.00" en un número decimal (1499.00) para poder sumarlo
      // Quitamos el "S/", las comas de los miles, y los espacios en blanco
      const precioNumero = parseFloat(
        precioTexto.replace("S/", "").replace(",", "").trim(),
      );

      // Creamos el objeto del producto guardando ambos datos
      const producto = {
        nombre: nombre,
        precioTexto: precioTexto, // Para mostrarlo bonito en la lista
        precioNumero: precioNumero, // Para hacer la suma matemática del total
      };

      // Lo agregamos a la lista del carrito
      carrito.push(producto);

      alert("¡Agregado! " + nombre + " ya está en tu carrito.");
    });
  }

  // --- PARTE 2: VER EL CARRITO (Con el Total a Pagar) ---
  const btnCarrito = document.getElementById("btnCarrito");

  if (btnCarrito) {
    btnCarrito.addEventListener("click", function () {
      if (carrito.length === 0) {
        alert(
          "Tu carrito está vacío \n¡Agrega algún producto antes de comprar!",
        );
      } else {
        let mensaje = " Resumen de tu carrito de CyberLap:\n\n";
        let total = 0; // Aquí acumularemos la suma

        // Recorremos el carrito para armar la lista y sumar los precios
        for (let i = 0; i < carrito.length; i++) {
          mensaje =
            mensaje +
            (i + 1) +
            ". " +
            carrito[i].nombre +
            " - " +
            carrito[i].precioTexto +
            "\n";
          total = total + carrito[i].precioNumero; // Sumamos el valor numérico
        }

        // Añadimos el total al mensaje final formateado con dos decimales
        mensaje = mensaje + "\n Total a pagar: S/ " + total.toFixed(2);
        mensaje = mensaje + "\n\n¿Listo para llevarte tu nueva máquina?";

        alert(mensaje);
      }
    });
  }

  // --- PARTE 3: BUSCADOR EN TIEMPO REAL ---
  const inputBuscador = document.querySelector(".buscador-input");
  const tarjetas = document.querySelectorAll(".tarjeta-producto");

  if (inputBuscador) {
    inputBuscador.addEventListener("input", function (evento) {
      const texto = evento.target.value.toLowerCase().trim();

      for (let i = 0; i < tarjetas.length; i++) {
        const titulo = tarjetas[i]
          .querySelector(".titulo-producto")
          .textContent.toLowerCase();

        if (titulo.includes(texto)) {
          tarjetas[i].style.display = "";
        } else {
          tarjetas[i].style.display = "none";
        }
      }
    });
  }
};
